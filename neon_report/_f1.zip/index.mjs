export default {
  async fetch(request) {
    const names = Object.keys(process.env).sort();
    return new Response(JSON.stringify({ env_names: names }, null, 1), {
      headers: { 'content-type': 'application/json' },
    });
  }
};
