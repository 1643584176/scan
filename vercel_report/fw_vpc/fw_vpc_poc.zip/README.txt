Vercel Sandbox custom-policy private-range bypass - PoC evidence
=====================================================================
1. _repro_min.py      - minimal repro (TCP connect + PG SSLRequest)
2. logs/              - raw outputs (same-sandbox 4-phase switch + sampling)
3. attribution/       - policy-field attribution scripts (deniedCIDRs fail-open, allowedCIDRs reversal)
4. REPORT-*.md        - submission + full report
Team: team_GIy1SZ444lspqeNbh4r8uAUg
Project: prj_iyw2xfjP3RKPT7n8b8c1tBIxxK5F
Compliance: TCP connect + 8B handshake only, no auth, no data read.
