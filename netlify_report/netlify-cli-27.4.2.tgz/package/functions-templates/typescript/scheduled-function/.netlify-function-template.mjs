export default {
  name: 'scheduled-function',
  priority: 1,
  description: 'Basic implementation of a scheduled function in TypeScript.',
  functionType: 'serverless',
}
